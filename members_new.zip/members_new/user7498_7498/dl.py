#!/home/user7498/Desktop/s2pro3/ib_ven/bin/python3
import os
import io
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
import time
import random


sleep_time = random.randint(1, 200)
print(sleep_time)
time.sleep(sleep_time)

# Path to your Service Account Credential json file
CREDENTIALS_FILE_PATH = "/home/user7498/Desktop/s2pro3/tactile-temple-409011-845594fbd784.json"

print('downloading')

# Specify the location you want to save the files
LOCAL_DOWNLOAD_PATH = '/home/user7498/Desktop/s2pro3'  



# Load credentials and create a service client
creds = Credentials.from_service_account_file(CREDENTIALS_FILE_PATH, scopes=["https://www.googleapis.com/auth/drive"])
drive_service = build('drive', 'v3', credentials=creds)



# The ID of the folder in Google Drive from which you want to download the files
FOLDER_ID = '1UuvI9OzzxON10uhws1QyglBrzsb8hG3a'



# List all files in the specified folder
results = drive_service.files().list(q=f"'{FOLDER_ID}' in parents and trashed = false", 
                                     fields="nextPageToken, files(id, name)").execute()
items = results.get('files', [])


for item in items:
    if item['name'].endswith('.csv'):
        print(f"Downloading file: {item['name']}")
        request = drive_service.files().get_media(fileId=item['id'])
        fh = io.FileIO(os.path.join(LOCAL_DOWNLOAD_PATH, item['name']), 'wb')
        downloader = MediaIoBaseDownload(fh, request)

        done = False
        while done is False:
            status, done = downloader.next_chunk()
            print(f"Download progress: {int(status.progress() * 100)}%")

        print(f"{item['name']} downloaded successfully.")