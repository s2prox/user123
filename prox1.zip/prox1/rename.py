import os
import shutil

def replace_text_in_file(file_path, old_text, new_text):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    updated_content = content.replace(old_text, new_text)

    if content != updated_content:  # Check if there was any change
        return updated_content
    return None

def main():
    base_dir = "/Users/alanyang/Dropbox/crontab_all_4"
    old_text = "prox1"
    new_text = "prox1"
    
    # Ensure the new directory exists
    new_dir = os.path.join(base_dir, new_text)
    if not os.path.exists(new_dir):
        os.makedirs(new_dir)

    for root, dirs, files in os.walk(base_dir):
        # Skip the newly created directory to avoid copying files twice
        if new_text in dirs:
            dirs.remove(new_text)
        
        for file in files:
            file_path = os.path.join(root, file)
            new_file_path = os.path.join(new_dir, file)
            
            if file.endswith('.py'):
                # Replace the text and get the new content if there was any change
                updated_content = replace_text_in_file(file_path, old_text, new_text)
                
                if updated_content is not None:
                    with open(new_file_path, 'w', encoding='utf-8') as f:
                        f.write(updated_content)
                else:
                    # If the content wasn't updated, we still copy it to the new directory
                    shutil.copy(file_path, new_file_path)
            else:
                # For non-Python files, just copy them to the new directory
                shutil.copy(file_path, new_file_path)

if __name__ == "__main__":
    main()
