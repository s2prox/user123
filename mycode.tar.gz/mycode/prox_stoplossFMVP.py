import subprocess
print('runing prox...')

def run_script(script_name):
    try:
        subprocess.check_call(['/home/user7496/Desktop/s2pro3/' + script_name])
        return True 
    except subprocess.CalledProcessError:
        return False

if __name__ == "__main__":
    if not run_script('prox_stoploss.py'):
        for i in range(20):  # Try to run 'prox_test.py' up to 3 times
            if run_script('prox_stoploss.py'):
                break  # If 'prox_now.py' runs successfully, exit the loop